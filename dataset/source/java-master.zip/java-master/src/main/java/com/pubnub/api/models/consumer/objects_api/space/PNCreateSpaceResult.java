package com.pubnub.api.models.consumer.objects_api.space;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class PNCreateSpaceResult {

    private PNSpace space;
}
