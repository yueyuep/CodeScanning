package com.pubnub.api.models.consumer.message_actions;

public class PNRemoveMessageActionResult {

}
