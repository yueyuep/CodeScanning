package com.pubnub.api.models.consumer.push;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
public class PNPushRemoveAllChannelsResult {
}
