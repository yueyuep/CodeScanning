package com.pubnub.api.managers.token_manager;

public interface TokenManagerPropertyProvider {

    TokenManagerProperties getTmsProperties();
}
