

### PubNub Java-based SDKs for Java / Android


[![Build Status](https://travis-ci.org/pubnub/java.svg?branch=master)](https://travis-ci.org/pubnub/java)
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/164fd518c314417e896b3de494ab75df)](https://www.codacy.com/app/PubNub/java?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=pubnub/java&amp;utm_campaign=Badge_Grade)
[![Codacy Badge](https://api.codacy.com/project/badge/Coverage/164fd518c314417e896b3de494ab75df)](https://www.codacy.com/app/PubNub/java?utm_source=github.com&utm_medium=referral&utm_content=pubnub/java&utm_campaign=Badge_Coverage)
[![Download](https://api.bintray.com/packages/bintray/jcenter/com.pubnub%3Apubnub-gson/images/download.svg)](https://bintray.com/bintray/jcenter/com.pubnub%3Apubnub-gson/_latestVersion)
[![Maven Central](https://img.shields.io/maven-central/v/com.pubnub/pubnub-gson.svg)]()

### [Documentation](https://www.pubnub.com/docs/java/pubnub-java-sdk-v4)

## Communication

- If you **need help** or have a **general question**, contact <support@pubnub.com>
